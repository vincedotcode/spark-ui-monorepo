import * as React from 'react';
import { cn } from '../../utils/cn';

/**
 * Defines the appearance of the button. The appearance determines the
 * overall look of the button (filled, outlined, soft or plain). When
 * combined with a colour the resulting class will be of the form
 * `ig-btn--{colour}-{appearance}`, e.g. `ig-btn--danger-filled`. For
 * the default colour (primary), omit the colour to generate classes
 * such as `ig-btn--filled`.
 */
export type ButtonAppearance = 'filled' | 'outlined' | 'soft' | 'plain';

/**
 * Semantic colour for the button. When provided along with an
 * appearance, the class name will combine the two (e.g.
 * `ig-btn--danger-filled`). When omitted, the default (primary)
 * styling from Ignite will be applied.
 */
export type ButtonColour = 'danger' | 'success';

export interface ButtonProps
  extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'color'> {
  /** The size of the button. Determines padding and font size. */
  size?: 'sm' | 'md' | 'lg';
  /**
   * The appearance of the button. Controls whether the button is filled,
   * outlined, soft or plain. Default is `filled`.
   */
  appearance?: ButtonAppearance;
  /**
   * Optional semantic colour for the button. When provided along with an
   * appearance, generates a colour-specific class (e.g.
   * `ig-btn--danger-filled`). Accepts `danger` and `success`. The
   * default colour (primary) is used when colour is undefined.
   */
  colour?: ButtonColour;
  /**
   * Optional icon to display at the start of the button label. Use
   * React nodes such as lucide-react icons. Ignored when children is
   * not a React node.
   */
  iconStart?: React.ReactNode;
  /**
   * Optional icon to display at the end of the button label.
   */
  iconEnd?: React.ReactNode;
  /**
   * Renders a loading state. When true, displays an Ignite spinner
   * (styled via `.ig-spinner`) and disables the button.
   */
  loading?: boolean;
  /**
   * When true, does not render a native `<button>` element. Instead
   * clones its single child and merges in the props and classes. This
   * allows the component to wrap around custom elements (e.g. Next.js
   * Link) similar to Radix’s `asChild` pattern.
   */
  asChild?: boolean;
}

/**
 * Spark UI Button component. Thin wrapper over Ignite’s button styles. It
 * composes CSS classes based on the provided props and defers all
 * visual styling to the Ignite design system (loaded separately via
 * CSS). Consumers must ensure the Ignite CSS is included in their
 * application, e.g. via a `<link>` tag in `_app.tsx` or by importing
 * the stylesheet in a global CSS file.
 */
export const Button = React.forwardRef<
  HTMLButtonElement,
  React.PropsWithChildren<ButtonProps>
>((props, ref) => {
  const {
    size = 'md',
    appearance = 'filled',
    colour,
    iconStart,
    iconEnd,
    loading = false,
    asChild = false,
    className,
    children,
    disabled,
    ...rest
  } = props;

  // Compute the CSS class names based on props. When a colour is
  // provided, combine it with the appearance (e.g. danger + filled →
  // `ig-btn--danger-filled`). Otherwise just use the appearance (e.g.
  // `ig-btn--outlined`).
  const colourClass = colour
    ? `ig-btn--${colour}-${appearance}`
    : `ig-btn--${appearance}`;
  const classes = cn(
    'ig-btn',
    size && `ig-btn--${size}`,
    colourClass,
    (iconStart || iconEnd) && 'ig-btn--icon',
    loading && 'ig-btn--loading',
    className
  );

  // If asChild is true and the single child is a valid element,
  // clone it and merge in the classes, ref and other props. This
  // pattern mirrors the behaviour of Radix UI’s Slot primitive.
  if (asChild && React.isValidElement(children)) {
    const child = children as React.ReactElement<any>;
    const childClassName = (child.props as any).className;
    return React.cloneElement(child, {
      className: cn(childClassName, classes),
      ref,
      disabled: disabled ?? loading || (child.props as any).disabled,
      ...rest,
    });
  }

  return (
    <button
      ref={ref}
      className={classes}
      disabled={disabled ?? loading}
      {...rest}
    >
      {/* Leading icon or spinner */}
      {loading ? (
        <div className="ig-spinner" />
      ) : (
        iconStart
      )}
      {/* Button label */}
      {children}
      {/* Trailing icon */}
      {iconEnd && !loading && iconEnd}
    </button>
  );
});

Button.displayName = 'Button';