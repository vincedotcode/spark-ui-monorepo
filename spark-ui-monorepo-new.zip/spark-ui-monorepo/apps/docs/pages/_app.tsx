import type { AppProps } from 'next/app';
import Head from 'next/head';

// Import the Spark UI tokens to make the design tokens available globally. These
// variables (colours, spacing, fonts, etc.) are defined in the component
// library and consumed by components. The Ignite CSS is pulled from the SD
// Worx CDN via a `<link>` tag in the Head element below.
import 'spark-ui/dist/tokens/tokens.css';

function MyApp({ Component, pageProps }: AppProps) {
  return (
    <>
      <Head>
        {/* Ignite design system styles – includes button styling and tokens */}
        <link
          rel="stylesheet"
          href="https://www.sd.be/ignite/develop/styles-TOIH6TY4.css"
        />
        {/* Ignite icon font definitions */}
        <link
          rel="stylesheet"
          href="https://cdn.sdworx.com/ignite/assets/fonts/all.css"
        />
        <title>Spark UI Docs</title>
      </Head>
      <Component {...pageProps} />
    </>
  );
}

export default MyApp;