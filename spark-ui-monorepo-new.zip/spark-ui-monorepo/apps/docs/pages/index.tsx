import { Button } from 'spark-ui';
import type { NextPage } from 'next';

/**
 * The landing page for the Spark UI documentation. Inspired by the shadcn
 * style of docs, this page introduces the component library, provides
 * installation instructions and showcases the Button component in its
 * various appearances, colours, sizes and states. Styling is provided
 * entirely by Ignite’s CSS (see `_app.tsx`), so there are no inline
 * styles aside from simple layout helpers.
 */
const Home: NextPage = () => {
  return (
    <main style={{ padding: '2rem', maxWidth: '960px', margin: '0 auto' }}>
      {/* Hero Section */}
      <section style={{ marginBottom: '3rem' }}>
        <h1 style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>Spark UI</h1>
        <p style={{ fontSize: '1.2rem', maxWidth: '60ch' }}>
          A lightweight, token‑driven React component library for Next.js. Spark UI
          leverages the Ignite design system to provide accessible, elegant
          components with minimal configuration.
        </p>
        <div style={{ marginTop: '1.5rem' }}>
          <Button size="lg">Get started</Button>
        </div>
      </section>

      {/* Getting Started Section */}
      <section style={{ marginBottom: '3rem' }}>
        <h2>Getting started</h2>
        <p>
          Install the package from npm. Spark UI has <code>react</code> and
          <code>react-dom</code> as peer dependencies. You’ll also need to
          include the Ignite CSS and fonts in your application. See
          <code>pages/_app.tsx</code> in this repository for an example.
        </p>
        <pre>
          <code>npm install spark-ui</code>
        </pre>
      </section>

      {/* Button Showcase */}
      <section>
        <h2>Button component</h2>
        <p>
          Buttons are clickable elements that trigger actions. They come in
          different appearances (filled, outlined, soft, plain), sizes and
          colours. Below you can see several examples rendered by the
          <code>&lt;Button&gt;</code> component.
        </p>

        {/* Appearance variants */}
        <h3>Appearances</h3>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', marginBottom: '1rem' }}>
          <Button appearance="filled">Filled</Button>
          <Button appearance="outlined">Outlined</Button>
          <Button appearance="soft">Soft</Button>
          <Button appearance="plain">Plain</Button>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
          <Button colour="danger" appearance="filled">Danger filled</Button>
          <Button colour="danger" appearance="outlined">Danger outlined</Button>
          <Button colour="danger" appearance="soft">Danger soft</Button>
          <Button colour="danger" appearance="plain">Danger plain</Button>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
          <Button colour="success" appearance="filled">Success filled</Button>
          <Button colour="success" appearance="outlined">Success outlined</Button>
          <Button colour="success" appearance="soft">Success soft</Button>
          <Button colour="success" appearance="plain">Success plain</Button>
        </div>

        {/* Sizes */}
        <h3>Sizes</h3>
        <div style={{ display: 'flex', gap: '1rem', marginBottom: '2rem' }}>
          <Button size="sm">Small</Button>
          <Button size="md">Medium</Button>
          <Button size="lg">Large</Button>
        </div>

        {/* With icons */}
        <h3>With icons</h3>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
          <Button size="sm" appearance="soft" iconStart={<i className="ig-icon-o-rocket" />}>
            Label
          </Button>
          <Button appearance="soft" colour="danger" iconEnd={<i className="ig-icon-o-right" />}>
            Label
          </Button>
          <Button size="lg" appearance="plain" colour="success" iconStart={<i className="ig-icon-o-star" />} iconEnd={<i className="ig-icon-o-holiday" />}>
            Label
          </Button>
        </div>

        {/* Icon only */}
        <h3>Icon only</h3>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', marginBottom: '2rem' }}>
          <Button appearance="filled" iconStart={<i className="ig-icon-o-trash" />} aria-label="Delete" />
          <Button appearance="outlined" iconStart={<i className="ig-icon-o-reboot" />} aria-label="Refresh" />
          <Button appearance="soft" colour="danger" iconStart={<i className="ig-icon-o-trash" />} aria-label="Danger delete" />
          <Button appearance="plain" colour="success" iconStart={<i className="ig-icon-o-whatsapp" />} aria-label="WhatsApp" />
        </div>

        {/* Loading state */}
        <h3>Loading</h3>
        <div style={{ display: 'flex', gap: '1rem', marginBottom: '2rem' }}>
          <Button loading appearance="filled" aria-label="Loading" />
          <Button loading appearance="outlined" />
          <Button loading appearance="soft" />
          <Button loading appearance="plain" />
        </div>
      </section>
    </main>
  );
};

export default Home;